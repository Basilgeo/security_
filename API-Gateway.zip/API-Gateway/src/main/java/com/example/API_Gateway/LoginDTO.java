package com.example.API_Gateway;


import lombok.Data;

@Data
public class LoginDTO {
    private String username;
    private String password;
}
