package com.example.API_Gateway;


import lombok.Data;

@Data
public class VendorRegisterDTO {
    private String username;
    private String name;
    private String contactEmail;
    private String password;
    private String contactPhoneNumber;
    private String address;
    private String location;
    private String businessCategory;
    private String storeName;
    private String profileImageUrl;
}

