package com.example.API_Gateway;


import lombok.Data;

@Data
public class CustomerRegisterDTO {
    private String username;
    private String password;
    private String email;
    private String phoneNumber;
    private String address;
    private String firstName;
    private String lastName;
    private String profileImageUrl;
}

