package com.example.API_Gateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping
public class ApiGatewayController {

    private final WebClient webClient;
    private final UserRepository userRepository;
    private final JwtService jwtService;
    private final BCryptPasswordEncoder passwordEncoder;

    @Autowired
    public ApiGatewayController(WebClient.Builder webClientBuilder, UserRepository userRepository, JwtService jwtService) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8888").build();
        this.userRepository = userRepository;
        this.jwtService = jwtService;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    @GetMapping
    public String checkpoint(){
        return "Working GO Sleep ! :)";
    }

    @PostMapping("/login")
    public Mono<ResponseEntity<?>> login(@RequestBody LoginDTO loginDto) {
        return userRepository.findByUsername(loginDto.getUsername())
                .flatMap(user -> {
                    if (passwordEncoder.matches(loginDto.getPassword(), user.getPasswordHash())) {
                        // Generate JWT token
                        String token = jwtService.generateToken(user);
                        return Mono.just(ResponseEntity.ok(new JwtResponse(token)));
                    } else {
                        return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                                .body(new ErrorResponse("Invalid credentials")));
                    }
                })
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new ErrorResponse("User not found"))));
    }

    @PostMapping("/register/customer")
    public Mono<ResponseEntity<String>> registerCustomer(@RequestBody CustomerRegisterDTO registerCustomerDto) {
        User user = new User();
        user.setUsername(registerCustomerDto.getUsername());
        user.setPasswordHash(passwordEncoder.encode(registerCustomerDto.getPassword()));
        user.setRole("ROLE_CUSTOMER");

        return userRepository.save(user)
                .flatMap(savedUser ->
                        webClient.post()
                                .uri("http://localhost:8081/customers")
                                .bodyValue(registerCustomerDto)
                                .retrieve()
                                .toEntity(String.class)
                                .map(response -> ResponseEntity.ok("Customer Registered"))
                )
                .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Registration failed")));
    }

    @PostMapping("/register/vendor")
    public Mono<ResponseEntity<String>> registerVendor(@RequestBody VendorRegisterDTO registerVendorDto) {
        User user = new User();
        user.setUsername(registerVendorDto.getUsername());
        user.setPasswordHash(passwordEncoder.encode(registerVendorDto.getPassword()));
        user.setRole("ROLE_VENDOR");

        return userRepository.save(user)
                .flatMap(savedUser ->
                        webClient.post()
                                .uri("http://localhost:8084/vendors")
                                .bodyValue(registerVendorDto)
                                .retrieve()
                                .toEntity(String.class)
                                .map(response -> ResponseEntity.ok("Vendor Registered"))
                )
                .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Registration failed")));
    }

    // DTO and Response classes
    public static class JwtResponse {
        private String token;

        public JwtResponse(String token) {
            this.token = token;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }
    }

    public static class ErrorResponse {
        private String message;

        public ErrorResponse(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
